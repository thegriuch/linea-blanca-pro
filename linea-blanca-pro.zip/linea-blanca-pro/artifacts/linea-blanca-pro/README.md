# Línea Blanca Pro 📱

**Plataforma de diagnóstico técnico guiado para técnicos de electrodomésticos.**

v2.0 · Expo SDK · React Native · TypeScript

---

## 🚀 Ejecutar en VS Code (desarrollo)

### Requisitos previos

| Herramienta | Versión mínima | Descarga |
|---|---|---|
| Node.js | 20+ | https://nodejs.org |
| pnpm | 9+ | `npm install -g pnpm` |
| Git | cualquiera | https://git-scm.com |

### Pasos

```bash
# 1. Clona el repositorio (raíz del monorepo)
git clone https://github.com/thegriuch/linea-blanca-pro.git
cd linea-blanca-pro

# 2. Instala dependencias desde la raíz
pnpm install

# 3. Inicia el servidor de desarrollo de la app
pnpm --filter @workspace/linea-blanca-pro run dev
```

Aparecerá un **código QR** en la terminal.

### Instalar en Android (desarrollo)

1. Instala **Expo Go** en tu Android: [play.google.com/store/apps/details?id=host.exp.exponent](https://play.google.com/store/apps/details?id=host.exp.exponent)
2. Abre Expo Go → **Escanea el QR** de la terminal
3. La app carga directamente en tu celular ✅

> El celular y la computadora deben estar en la **misma red WiFi**.

---

## 📦 Generar APK independiente (sin Expo Go)

El APK permite instalar la app en **cualquier Android** sin necesitar Expo Go ni conexión a internet.

### Requisitos adicionales

- Cuenta gratuita en [expo.dev](https://expo.dev) (registro en 2 minutos)
- EAS CLI: `npm install -g eas-cli`

### Pasos

```bash
# Desde la carpeta de la app
cd artifacts/linea-blanca-pro

# 1. Inicia sesión en tu cuenta Expo
eas login

# 2. Configura el proyecto (solo la primera vez)
eas build:configure

# 3. Compila el APK (tarda ~10-15 min en los servidores de Expo)
eas build --platform android --profile preview

# 4. Al terminar, EAS muestra un enlace para descargar el .apk
```

El archivo `.apk` se descarga y puede enviarse por WhatsApp, correo o cualquier medio. En el Android: **Ajustes → Seguridad → Instalar apps desconocidas**.

### Build automático con GitHub Actions

Cada `push` a `main` dispara una compilación automática:

1. Ve a **Settings → Secrets → Actions** en tu repo de GitHub
2. Agrega el secret `EXPO_TOKEN` con tu token de [expo.dev/settings/access-tokens](https://expo.dev/settings/access-tokens)
3. El APK queda disponible en la pestaña **Actions → Build Android APK → Artifacts**

---

## 🗂 Estructura del proyecto

```
linea-blanca-pro/          ← este repositorio (monorepo pnpm)
├── artifacts/
│   └── linea-blanca-pro/  ← app Expo
│       ├── app/           ← pantallas (Expo Router)
│       │   ├── (tabs)/    ← Inicio, Diagnóstico, Historial, Biblioteca, Buscar
│       │   └── diagnostico/ ← flujo de diagnóstico guiado
│       ├── components/    ← componentes UI reutilizables
│       ├── constants/     ← árboles de decisión, fallas, equipos
│       ├── contexts/      ← estado global (AsyncStorage)
│       ├── types/         ← tipos TypeScript
│       ├── utils/         ← generador de reportes + compartir
│       ├── app.json       ← configuración Expo
│       └── eas.json       ← configuración de builds
├── pnpm-workspace.yaml
└── package.json
```

---

## ✨ Funcionalidades

- **Diagnóstico guiado** por árbol de decisión (12 fallas distintas)
- **Captura de evidencia fotográfica** en pasos clave
- **Historial persistente** de diagnósticos anteriores
- **Generación y compartir de reportes** en texto
- **Biblioteca técnica** con fichas de componentes
- **Buscador de síntomas** con clasificación por probabilidad

---

## 🛠 Tecnologías

- [Expo SDK](https://expo.dev) + [Expo Router](https://expo.github.io/router)
- React Native + TypeScript
- AsyncStorage (persistencia local, sin backend)
- expo-image-picker, expo-sharing, expo-file-system

---

## 📄 Licencia

Uso interno / privado. Todos los derechos reservados.
