import type { EquipoTipo, FaultItem } from '@/types/diagnostico';

export const FALLAS_POR_EQUIPO: Record<EquipoTipo, FaultItem[]> = {
  nevera: [
    { id: 'noenfria', label: 'No enfría', treeId: 'noenfria', icon: 'thermometer' },
    { id: 'congela-mucho', label: 'Congela demasiado', treeId: 'congelamucho', icon: 'alert-triangle' },
    { id: 'fuga-agua', label: 'Fuga de agua', treeId: 'fuga_agua', icon: 'droplet' },
    { id: 'noarranque', label: 'Compresor no arranca', treeId: 'noarranque', icon: 'zap-off' },
    { id: 'ruido', label: 'Ruido excesivo', treeId: 'ruidoexcesivo', icon: 'volume-2' },
    { id: 'error-electronico', label: 'Error electrónico', treeId: 'errorelectronico', icon: 'cpu' },
    { id: 'escarcha', label: 'Escarcha excesiva', treeId: 'escarcha', icon: 'cloud-snow' },
    { id: 'noenciende', label: 'No enciende / Sin luz', treeId: 'noenciende', icon: 'power' },
    { id: 'alto-consumo', label: 'Alto consumo eléctrico', treeId: 'noenfria', icon: 'activity' },
    { id: 'ventilador', label: 'Ventilador no funciona', treeId: 'ruidoexcesivo', icon: 'wind' },
    { id: 'descongela', label: 'Descongela alimentos', treeId: 'noenfria', icon: 'sun' },
    { id: 'display', label: 'Display apagado', treeId: 'errorelectronico', icon: 'monitor' },
  ],
  congelador: [
    { id: 'noenfria', label: 'No congela bien', treeId: 'noenfria', icon: 'thermometer' },
    { id: 'fuga-agua', label: 'Fuga de agua', treeId: 'fuga_agua', icon: 'droplet' },
    { id: 'noarranque', label: 'Compresor no arranca', treeId: 'noarranque', icon: 'zap-off' },
    { id: 'ruido', label: 'Ruido excesivo', treeId: 'ruidoexcesivo', icon: 'volume-2' },
    { id: 'noenciende', label: 'No enciende', treeId: 'noenciende', icon: 'power' },
    { id: 'escarcha', label: 'Escarcha excesiva', treeId: 'escarcha', icon: 'cloud-snow' },
  ],
  nevecon: [
    { id: 'noenfria', label: 'No enfría', treeId: 'noenfria', icon: 'thermometer' },
    { id: 'congela-mucho', label: 'Congela demasiado', treeId: 'congelamucho', icon: 'alert-triangle' },
    { id: 'fuga-agua', label: 'Fuga de agua', treeId: 'fuga_agua', icon: 'droplet' },
    { id: 'noarranque', label: 'Compresor no arranca', treeId: 'noarranque', icon: 'zap-off' },
    { id: 'ruido', label: 'Ruido excesivo', treeId: 'ruidoexcesivo', icon: 'volume-2' },
    { id: 'error-electronico', label: 'Error electrónico', treeId: 'errorelectronico', icon: 'cpu' },
    { id: 'escarcha', label: 'Escarcha excesiva', treeId: 'escarcha', icon: 'cloud-snow' },
    { id: 'noenciende', label: 'No enciende', treeId: 'noenciende', icon: 'power' },
  ],
  minibar: [
    { id: 'noenfria', label: 'No enfría', treeId: 'noenfria', icon: 'thermometer' },
    { id: 'ruido', label: 'Ruido excesivo', treeId: 'ruidoexcesivo', icon: 'volume-2' },
    { id: 'noenciende', label: 'No enciende', treeId: 'noenciende', icon: 'power' },
    { id: 'fuga-agua', label: 'Fuga de agua', treeId: 'fuga_agua', icon: 'droplet' },
  ],
  lavadora: [
    { id: 'nocentrifuga', label: 'No centrifuga', treeId: 'nocentrifuga', icon: 'rotate-cw' },
    { id: 'nodesagua', label: 'No desagua', treeId: 'nodesagua', icon: 'arrow-down-circle' },
    { id: 'nollena', label: 'No llena / No toma agua', treeId: 'nollena', icon: 'arrow-up-circle' },
    { id: 'noenciende', label: 'No enciende', treeId: 'noenciende', icon: 'power' },
    { id: 'error-e1', label: 'Error E1 / E2 / F5', treeId: 'errorelectronico', icon: 'alert-circle' },
    { id: 'ruido', label: 'Ruido / Vibración excesiva', treeId: 'ruidoexcesivo', icon: 'volume-2' },
    { id: 'fuga-agua', label: 'Fuga de agua', treeId: 'fuga_agua', icon: 'droplet' },
    { id: 'nolavado', label: 'No lava bien', treeId: 'nocentrifuga', icon: 'x-circle' },
  ],
  secadora: [
    { id: 'noseca', label: 'No seca bien', treeId: 'noenfria', icon: 'wind' },
    { id: 'noenciende', label: 'No enciende', treeId: 'noenciende', icon: 'power' },
    { id: 'ruido', label: 'Ruido excesivo', treeId: 'ruidoexcesivo', icon: 'volume-2' },
    { id: 'error-electronico', label: 'Error electrónico', treeId: 'errorelectronico', icon: 'cpu' },
    { id: 'nocentrifuga', label: 'Tambor no gira', treeId: 'nocentrifuga', icon: 'rotate-cw' },
  ],
  aire: [
    { id: 'noenfria-aire', label: 'No enfría', treeId: 'noenfria_aire', icon: 'thermometer' },
    { id: 'noarranque', label: 'Compresor no arranca', treeId: 'noarranque', icon: 'zap-off' },
    { id: 'ventilador', label: 'Ventilador no funciona', treeId: 'ruidoexcesivo', icon: 'wind' },
    { id: 'fuga-agua', label: 'Fuga de agua / condensado', treeId: 'fuga_agua', icon: 'droplet' },
    { id: 'error-electronico', label: 'Error electrónico', treeId: 'errorelectronico', icon: 'cpu' },
    { id: 'ruido', label: 'Ruido excesivo', treeId: 'ruidoexcesivo', icon: 'volume-2' },
    { id: 'noenciende', label: 'No enciende / No responde control', treeId: 'noenciende', icon: 'power' },
  ],
  otro: [
    { id: 'noenciende', label: 'No enciende', treeId: 'noenciende', icon: 'power' },
    { id: 'falla-general', label: 'Falla general', treeId: 'noenciende', icon: 'tool' },
    { id: 'ruido', label: 'Ruido excesivo', treeId: 'ruidoexcesivo', icon: 'volume-2' },
    { id: 'error-electronico', label: 'Error electrónico', treeId: 'errorelectronico', icon: 'cpu' },
    { id: 'fuga-agua', label: 'Fuga de agua', treeId: 'fuga_agua', icon: 'droplet' },
  ],
};

export function getFallas(tipo: EquipoTipo): FaultItem[] {
  return FALLAS_POR_EQUIPO[tipo] ?? [];
}
