import type { EquipoTipo, EquipoTipoInfo } from '@/types/diagnostico';

export const EQUIPOS: EquipoTipoInfo[] = [
  { id: 'nevera', label: 'Nevera / Refrigerador', icon: 'package', color: '#145DA0' },
  { id: 'congelador', label: 'Congelador', icon: 'box', color: '#1A77C9' },
  { id: 'nevecon', label: 'Nevecón', icon: 'server', color: '#0D4B8A' },
  { id: 'minibar', label: 'Minibar', icon: 'grid', color: '#2563EB' },
  { id: 'lavadora', label: 'Lavadora / Secadora', icon: 'refresh-cw', color: '#0891B2' },
  { id: 'secadora', label: 'Secadora', icon: 'wind', color: '#0284C7' },
  { id: 'aire', label: 'Aire Acondicionado', icon: 'wind', color: '#047857' },
  { id: 'otro', label: 'Otro Equipo', icon: 'tool', color: '#64748B' },
];

export function getEquipoInfo(tipo: EquipoTipo): EquipoTipoInfo {
  return EQUIPOS.find((e) => e.id === tipo) ?? EQUIPOS[EQUIPOS.length - 1];
}
