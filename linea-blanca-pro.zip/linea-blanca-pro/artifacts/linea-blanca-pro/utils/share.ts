import { Platform } from 'react-native';
import type { DiagnosticSession } from '@/types/diagnostico';
import { getEquipoInfo } from '@/constants/equipos';

function fmt(d: string | undefined): string {
  if (!d) return '—';
  return new Date(d).toLocaleString('es-CO', {
    day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit',
  });
}

export function buildReportText(session: DiagnosticSession): string {
  const equipo = getEquipoInfo(session.equipo.tipo);
  const causes = session.result?.causes ?? [];
  const lines: string[] = [
    '══════════════════════════════',
    '  LÍNEA BLANCA PRO — REPORTE TÉCNICO',
    '══════════════════════════════',
    '',
    `TÉCNICO: ${session.tecnico || '—'}`,
    `FECHA INICIO: ${fmt(session.startedAt)}`,
    `FECHA FIN: ${fmt(session.finishedAt)}`,
    '',
    '── CLIENTE ─────────────────',
    `Nombre: ${session.cliente.nombre || '—'}`,
    `Teléfono: ${session.cliente.telefono || '—'}`,
    `Dirección: ${session.cliente.direccion || '—'}`,
    `Ciudad: ${session.cliente.ciudad || '—'}`,
    '',
    '── EQUIPO ──────────────────',
    `Tipo: ${equipo.label}`,
    `Marca: ${session.equipo.marca || '—'}`,
    `Modelo: ${session.equipo.modelo || '—'}`,
    `Serie: ${session.equipo.serie || '—'}`,
    `Falla reportada: ${session.equipo.fallaLabel || '—'}`,
    '',
  ];

  if (causes.length > 0) {
    lines.push('── DIAGNÓSTICO ─────────────');
    causes.forEach((c, i) => {
      lines.push(`  ${i + 1}. ${c.cause} — ${c.probability}%`);
    });
    lines.push('');
    if (session.result?.recommendation) {
      lines.push('RECOMENDACIÓN:');
      lines.push(session.result.recommendation);
      lines.push('');
    }
    if (session.result?.parts && session.result.parts.length > 0) {
      lines.push('REPUESTOS POSIBLES:');
      session.result.parts.forEach((p) => lines.push(`  • ${p}`));
      lines.push('');
    }
  }

  if (session.conclusion.diagnostico) {
    lines.push('── CONCLUSIÓN TÉCNICA ──────');
    lines.push(session.conclusion.diagnostico);
    lines.push('');
  }
  if (session.conclusion.repuestos) {
    lines.push(`REPUESTOS SOLICITADOS: ${session.conclusion.repuestos}`);
  }
  if (session.conclusion.tiempoEstimado) {
    lines.push(`TIEMPO ESTIMADO: ${session.conclusion.tiempoEstimado}`);
  }
  if (session.conclusion.observaciones) {
    lines.push(`OBSERVACIONES: ${session.conclusion.observaciones}`);
  }
  if (session.evidence.length > 0) {
    lines.push('');
    lines.push(`EVIDENCIAS: ${session.evidence.length} foto(s) adjunta(s)`);
  }
  lines.push('');
  lines.push('══════════════════════════════');
  return lines.join('\n');
}

export async function shareReport(session: DiagnosticSession): Promise<void> {
  const text = buildReportText(session);
  if (Platform.OS === 'web') {
    try {
      await navigator.clipboard.writeText(text);
    } catch (_) {
      alert(text);
    }
    return;
  }
  try {
    const Sharing = await import('expo-sharing');
    const FileSystem = await import('expo-file-system');
    const fileName = `reporte_${session.id}.txt`;
    const fileUri = (FileSystem.default.documentDirectory ?? '') + fileName;
    await FileSystem.default.writeAsStringAsync(fileUri, text, {
      encoding: FileSystem.default.EncodingType.UTF8,
    });
    if (await Sharing.default.isAvailableAsync()) {
      await Sharing.default.shareAsync(fileUri, {
        mimeType: 'text/plain',
        dialogTitle: 'Compartir reporte técnico',
      });
    }
  } catch (_) {
    // fallback
  }
}
