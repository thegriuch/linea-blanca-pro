import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import type {
  ClienteInfo,
  ConclusionInfo,
  DiagnosticCause,
  DiagnosticSession,
  EquipoInfo,
  Evidence,
} from '@/types/diagnostico';

const STORAGE_KEY = '@lbpro_sessions_v2';
const TECNICO_KEY = '@lbpro_tecnico_v2';

interface DiagnosticoContextType {
  isLoading: boolean;
  currentSession: DiagnosticSession | null;
  sessions: DiagnosticSession[];
  tecnico: string;
  setTecnico: (name: string) => void;
  startSession: () => void;
  updateCliente: (data: Partial<ClienteInfo>) => void;
  setEquipo: (equipo: EquipoInfo) => void;
  advanceNode: (nextNodeId: string, answerLabel?: string) => void;
  addEvidence: (evidence: Omit<Evidence, 'id' | 'createdAt'>) => void;
  removeEvidence: (evidenceId: string) => void;
  setConclusion: (data: Partial<ConclusionInfo>) => void;
  setResult: (result: { causes: DiagnosticCause[]; recommendation: string; parts: string[] }) => void;
  completeSession: () => DiagnosticSession | null;
  discardSession: () => void;
  deleteSession: (id: string) => void;
  getSession: (id: string) => DiagnosticSession | undefined;
}

const DiagnosticoContext = createContext<DiagnosticoContextType | null>(null);

function genId(): string {
  return Date.now().toString() + Math.random().toString(36).substr(2, 9);
}

function emptyCliente(): ClienteInfo {
  return { nombre: '', telefono: '', direccion: '', ciudad: '' };
}

function emptyConclusion(): ConclusionInfo {
  return { diagnostico: '', repuestos: '', tiempoEstimado: '', observaciones: '' };
}

export function DiagnosticoProvider({ children }: { children: React.ReactNode }) {
  const [isLoading, setIsLoading] = useState(true);
  const [currentSession, setCurrentSession] = useState<DiagnosticSession | null>(null);
  const [sessions, setSessions] = useState<DiagnosticSession[]>([]);
  const [tecnico, setTecnicoState] = useState('');

  useEffect(() => {
    (async () => {
      try {
        const [rawSessions, rawTecnico] = await Promise.all([
          AsyncStorage.getItem(STORAGE_KEY),
          AsyncStorage.getItem(TECNICO_KEY),
        ]);
        if (rawSessions) setSessions(JSON.parse(rawSessions));
        if (rawTecnico) setTecnicoState(rawTecnico);
      } catch (_) {
        // ignore storage errors
      } finally {
        setIsLoading(false);
      }
    })();
  }, []);

  const persistSessions = useCallback(async (updated: DiagnosticSession[]) => {
    try {
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    } catch (_) { /* ignore */ }
  }, []);

  const setTecnico = useCallback((name: string) => {
    setTecnicoState(name);
    AsyncStorage.setItem(TECNICO_KEY, name).catch(() => { /* ignore */ });
  }, []);

  const startSession = useCallback(() => {
    const session: DiagnosticSession = {
      id: genId(),
      startedAt: new Date().toISOString(),
      tecnico,
      cliente: emptyCliente(),
      equipo: {
        tipo: 'nevera',
        marca: '',
        modelo: '',
        serie: '',
        fallaId: '',
        fallaLabel: '',
        treeId: '',
      },
      path: [],
      pathAnswers: {},
      evidence: [],
      currentNodeId: 'start',
      completed: false,
      conclusion: emptyConclusion(),
    };
    setCurrentSession(session);
  }, [tecnico]);

  const updateCliente = useCallback((data: Partial<ClienteInfo>) => {
    setCurrentSession((prev) =>
      prev ? { ...prev, cliente: { ...prev.cliente, ...data } } : prev
    );
  }, []);

  const setEquipo = useCallback((equipo: EquipoInfo) => {
    setCurrentSession((prev) =>
      prev ? { ...prev, equipo, currentNodeId: 'start', path: [], pathAnswers: {} } : prev
    );
  }, []);

  const advanceNode = useCallback((nextNodeId: string, answerLabel?: string) => {
    setCurrentSession((prev) => {
      if (!prev) return prev;
      const path = [...prev.path, prev.currentNodeId];
      const pathAnswers = answerLabel
        ? { ...prev.pathAnswers, [prev.currentNodeId]: answerLabel }
        : prev.pathAnswers;
      return { ...prev, currentNodeId: nextNodeId, path, pathAnswers };
    });
  }, []);

  const addEvidence = useCallback((evidence: Omit<Evidence, 'id' | 'createdAt'>) => {
    setCurrentSession((prev) => {
      if (!prev) return prev;
      const newEvidence: Evidence = {
        ...evidence,
        id: genId(),
        createdAt: new Date().toISOString(),
      };
      return { ...prev, evidence: [...prev.evidence, newEvidence] };
    });
  }, []);

  const removeEvidence = useCallback((evidenceId: string) => {
    setCurrentSession((prev) => {
      if (!prev) return prev;
      return { ...prev, evidence: prev.evidence.filter((e) => e.id !== evidenceId) };
    });
  }, []);

  const setConclusion = useCallback((data: Partial<ConclusionInfo>) => {
    setCurrentSession((prev) =>
      prev ? { ...prev, conclusion: { ...prev.conclusion, ...data } } : prev
    );
  }, []);

  const setResult = useCallback((result: { causes: DiagnosticCause[]; recommendation: string; parts: string[] }) => {
    setCurrentSession((prev) => prev ? { ...prev, result } : prev);
  }, []);

  const completeSession = useCallback((): DiagnosticSession | null => {
    if (!currentSession) return null;
    const completed: DiagnosticSession = {
      ...currentSession,
      completed: true,
      finishedAt: new Date().toISOString(),
    };
    setSessions((prev) => {
      const updated = [completed, ...prev];
      persistSessions(updated);
      return updated;
    });
    setCurrentSession(null);
    return completed;
  }, [currentSession, persistSessions]);

  const discardSession = useCallback(() => {
    setCurrentSession(null);
  }, []);

  const deleteSession = useCallback((id: string) => {
    setSessions((prev) => {
      const updated = prev.filter((s) => s.id !== id);
      persistSessions(updated);
      return updated;
    });
  }, [persistSessions]);

  const getSession = useCallback((id: string) => {
    return sessions.find((s) => s.id === id);
  }, [sessions]);

  return (
    <DiagnosticoContext.Provider
      value={{
        isLoading,
        currentSession,
        sessions,
        tecnico,
        setTecnico,
        startSession,
        updateCliente,
        setEquipo,
        advanceNode,
        addEvidence,
        removeEvidence,
        setConclusion,
        setResult,
        completeSession,
        discardSession,
        deleteSession,
        getSession,
      }}
    >
      {children}
    </DiagnosticoContext.Provider>
  );
}

export function useDiagnostico(): DiagnosticoContextType {
  const ctx = useContext(DiagnosticoContext);
  if (!ctx) throw new Error('useDiagnostico must be used within DiagnosticoProvider');
  return ctx;
}
