import React, { useEffect, useState } from 'react';
import {
  Alert,
  Image,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { router } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import * as Haptics from 'expo-haptics';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { useDiagnostico } from '@/contexts/DiagnosticoContext';
import { PrimaryButton } from '@/components/PrimaryButton';
import { getNode } from '@/constants/arboles';
import type { TreeNode } from '@/types/diagnostico';
import colors from '@/constants/colors';

const NODE_TYPE_ICON: Record<string, keyof typeof Feather.glyphMap> = {
  question: 'help-circle',
  action: 'tool',
  measure: 'activity',
  evidence: 'camera',
  result: 'check-circle',
};

const NODE_TYPE_LABEL: Record<string, string> = {
  question: 'PREGUNTA',
  action: 'ACCIÓN',
  measure: 'MEDICIÓN',
  evidence: 'EVIDENCIA',
  result: 'RESULTADO',
};

const NODE_TYPE_COLOR: Record<string, string> = {
  question: '#145DA0',
  action: '#F5821F',
  measure: '#047857',
  evidence: '#7C3AED',
  result: '#15803D',
};

export default function ArbolScreen() {
  const c = useColors();
  const insets = useSafeAreaInsets();
  const { currentSession, advanceNode, addEvidence, setResult } = useDiagnostico();
  const [evidenceUri, setEvidenceUri] = useState<string | null>(null);

  if (!currentSession) {
    router.replace('/diagnostico/nuevo');
    return null;
  }

  const { equipo, currentNodeId, path } = currentSession;
  const node: TreeNode = getNode(equipo.treeId, currentNodeId);

  // When we land on a result node, save the result and go to conclusion
  useEffect(() => {
    if (node.type === 'result' && node.result) {
      setResult({
        causes: node.result.causes,
        recommendation: node.result.recommendation,
        parts: node.result.parts ?? [],
      });
      router.push('/diagnostico/conclusion');
    }
  }, [node.id]);

  const nodeColor = NODE_TYPE_COLOR[node.type] ?? c.primary;

  const handleOption = (nextId: string, label: string) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    advanceNode(nextId, label);
    setEvidenceUri(null);
  };

  const handleContinue = () => {
    if (!node.nextId) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    advanceNode(node.nextId);
    setEvidenceUri(null);
  };

  const handleCapturePhoto = async () => {
    if (Platform.OS === 'web') {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: 'images',
        quality: 0.8,
      });
      if (!result.canceled && result.assets[0]) {
        const uri = result.assets[0].uri;
        setEvidenceUri(uri);
        addEvidence({ uri, nodeId: node.id, nodeText: node.text });
      }
      return;
    }
    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permiso requerido', 'La app necesita acceso a la cámara para tomar evidencia.');
      return;
    }
    const result = await ImagePicker.launchCameraAsync({
      mediaTypes: 'images',
      quality: 0.8,
    });
    if (!result.canceled && result.assets[0]) {
      const uri = result.assets[0].uri;
      setEvidenceUri(uri);
      addEvidence({ uri, nodeId: node.id, nodeText: node.text });
    }
  };

  const handleBack = () => {
    if (path.length === 0) {
      router.back();
      return;
    }
    // Note: we can't easily go back in the tree without storing full state
    // So we just navigate back in the stack
    router.back();
  };

  const stepsCompleted = path.length;

  if (node.type === 'result') return null; // handled by useEffect

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: c.background }}
      contentContainerStyle={{
        padding: 20,
        paddingBottom: Platform.OS === 'web' ? 34 : insets.bottom + 40,
      }}
    >
      {/* Progress */}
      <View style={[styles.progressRow, { backgroundColor: c.muted, borderRadius: 6 }]}>
        <View style={[styles.progressFill, { backgroundColor: c.primary, width: `${Math.min(100, stepsCompleted * 8)}%`, borderRadius: 6 }]} />
      </View>
      <Text style={[styles.progressLabel, { color: c.mutedForeground }]}>
        Paso {stepsCompleted + 1} del árbol diagnóstico
      </Text>

      {/* Node type badge */}
      <View style={[styles.typeBadge, { backgroundColor: nodeColor + '18', borderRadius: 8 }]}>
        <Feather name={NODE_TYPE_ICON[node.type]} size={14} color={nodeColor} />
        <Text style={[styles.typeBadgeText, { color: nodeColor }]}>{NODE_TYPE_LABEL[node.type]}</Text>
      </View>

      {/* Node card */}
      <View style={[styles.nodeCard, { backgroundColor: c.card, borderColor: nodeColor, borderRadius: colors.radius }]}>
        <Text style={[styles.nodeText, { color: c.foreground }]}>{node.text}</Text>
        {node.detail && (
          <Text style={[styles.nodeDetail, { color: c.mutedForeground }]}>{node.detail}</Text>
        )}
        {node.tip && (
          <View style={[styles.tipBox, { backgroundColor: c.secondary, borderRadius: 10 }]}>
            <Feather name="info" size={14} color={c.primary} />
            <Text style={[styles.tipText, { color: c.secondaryForeground }]}>{node.tip}</Text>
          </View>
        )}
      </View>

      {/* Evidence capture (for evidence nodes) */}
      {node.type === 'evidence' && (
        <View style={styles.evidenceSection}>
          {evidenceUri ? (
            <View style={styles.evidencePreview}>
              <Image source={{ uri: evidenceUri }} style={[styles.evidenceImg, { borderRadius: colors.radius }]} />
              <View style={[styles.evidenceCheckBadge, { backgroundColor: c.success }]}>
                <Feather name="check" size={14} color={c.successForeground} />
              </View>
            </View>
          ) : null}
          <TouchableOpacity
            onPress={handleCapturePhoto}
            activeOpacity={0.75}
            style={[styles.captureBtn, { backgroundColor: '#7C3AED18', borderColor: '#7C3AED', borderRadius: colors.radius }]}
          >
            <Feather name="camera" size={20} color="#7C3AED" />
            <Text style={[styles.captureBtnText, { color: '#7C3AED' }]}>
              {evidenceUri ? 'Tomar otra foto' : 'Abrir cámara'}
            </Text>
          </TouchableOpacity>
          {node.evidenceLabel && (
            <Text style={[styles.evidenceLabel, { color: c.mutedForeground }]}>{node.evidenceLabel}</Text>
          )}
        </View>
      )}

      {/* Options (for question nodes) */}
      {node.type === 'question' && node.options && (
        <View style={styles.options}>
          {node.options.map((opt, i) => {
            const optColor =
              opt.color === 'success' ? c.success
              : opt.color === 'danger' ? c.destructive
              : c.primary;
            return (
              <TouchableOpacity
                key={i}
                onPress={() => handleOption(opt.nextId, opt.label)}
                activeOpacity={0.75}
                style={[
                  styles.optionBtn,
                  { borderColor: optColor, backgroundColor: optColor + '08', borderRadius: colors.radius },
                ]}
              >
                <Feather name="chevron-right" size={16} color={optColor} />
                <Text style={[styles.optionText, { color: optColor }]}>{opt.label}</Text>
              </TouchableOpacity>
            );
          })}
        </View>
      )}

      {/* Continue button (for action / measure / evidence nodes) */}
      {(node.type === 'action' || node.type === 'measure' || node.type === 'evidence') && node.nextId && (
        <View style={styles.continueSection}>
          {node.type === 'evidence' && !evidenceUri && (
            <TouchableOpacity onPress={handleContinue} style={styles.skipLink}>
              <Text style={[styles.skipText, { color: c.mutedForeground }]}>Omitir evidencia y continuar</Text>
            </TouchableOpacity>
          )}
          {(node.type !== 'evidence' || evidenceUri) && (
            <PrimaryButton
              label={node.type === 'evidence' ? 'Guardar evidencia y continuar' : 'Continuar'}
              icon="arrow-right"
              onPress={handleContinue}
            />
          )}
        </View>
      )}

      {/* Back */}
      <View style={{ marginTop: 12 }}>
        <PrimaryButton label="Volver" variant="outline" onPress={handleBack} />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  progressRow: {
    height: 6,
    marginBottom: 6,
    overflow: 'hidden',
  },
  progressFill: {
    height: 6,
    minWidth: 12,
  },
  progressLabel: {
    fontSize: 12,
    marginBottom: 16,
    fontFamily: Platform.select({ ios: 'System', default: 'Inter_400Regular' }),
  },
  typeBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    alignSelf: 'flex-start',
    paddingHorizontal: 10,
    paddingVertical: 5,
    marginBottom: 12,
  },
  typeBadgeText: {
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 0.5,
    fontFamily: Platform.select({ ios: 'System', default: 'Inter_700Bold' }),
  },
  nodeCard: {
    borderWidth: 2,
    padding: 18,
    marginBottom: 20,
    gap: 10,
  },
  nodeText: {
    fontSize: 18,
    fontWeight: '700',
    lineHeight: 25,
    fontFamily: Platform.select({ ios: 'System', default: 'Inter_700Bold' }),
  },
  nodeDetail: {
    fontSize: 13,
    lineHeight: 19,
    fontFamily: Platform.select({ ios: 'System', default: 'Inter_400Regular' }),
  },
  tipBox: {
    flexDirection: 'row',
    gap: 8,
    padding: 12,
    alignItems: 'flex-start',
  },
  tipText: {
    flex: 1,
    fontSize: 12,
    lineHeight: 17,
    fontFamily: Platform.select({ ios: 'System', default: 'Inter_400Regular' }),
  },
  evidenceSection: {
    marginBottom: 16,
    gap: 10,
  },
  evidencePreview: {
    position: 'relative',
    alignSelf: 'center',
  },
  evidenceImg: {
    width: 200,
    height: 150,
  },
  evidenceCheckBadge: {
    position: 'absolute',
    top: 8,
    right: 8,
    width: 28,
    height: 28,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  captureBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    padding: 16,
    borderWidth: 1.5,
    borderStyle: 'dashed',
  },
  captureBtnText: {
    fontSize: 15,
    fontWeight: '600',
    fontFamily: Platform.select({ ios: 'System', default: 'Inter_600SemiBold' }),
  },
  evidenceLabel: {
    fontSize: 12,
    textAlign: 'center',
    fontFamily: Platform.select({ ios: 'System', default: 'Inter_400Regular' }),
  },
  options: {
    gap: 10,
    marginBottom: 12,
  },
  optionBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 16,
    borderWidth: 1.5,
  },
  optionText: {
    flex: 1,
    fontSize: 15,
    fontWeight: '600',
    fontFamily: Platform.select({ ios: 'System', default: 'Inter_600SemiBold' }),
  },
  continueSection: {
    gap: 10,
  },
  skipLink: {
    alignItems: 'center',
    padding: 10,
  },
  skipText: {
    fontSize: 13,
    textDecorationLine: 'underline',
    fontFamily: Platform.select({ ios: 'System', default: 'Inter_400Regular' }),
  },
});
