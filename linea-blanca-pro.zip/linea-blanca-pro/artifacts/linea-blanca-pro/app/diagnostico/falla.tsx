import React, { useState } from 'react';
import { Alert, Platform, ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { router } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { useDiagnostico } from '@/contexts/DiagnosticoContext';
import { PrimaryButton } from '@/components/PrimaryButton';
import { StepProgress } from '@/components/StepProgress';
import { FormField } from '@/components/FormField';
import { getFallas } from '@/constants/fallas';
import { getEquipoInfo } from '@/constants/equipos';
import colors from '@/constants/colors';
import type { FaultItem } from '@/types/diagnostico';

const STEPS = ['Datos', 'Equipo', 'Falla'];

export default function FallaScreen() {
  const c = useColors();
  const insets = useSafeAreaInsets();
  const { currentSession, updateCliente, setEquipo } = useDiagnostico();
  const [marca, setMarca] = useState(currentSession?.equipo.marca ?? '');
  const [modelo, setModelo] = useState(currentSession?.equipo.modelo ?? '');
  const [serie, setSerie] = useState(currentSession?.equipo.serie ?? '');
  const [selectedFalla, setSelectedFalla] = useState<FaultItem | null>(null);

  if (!currentSession) {
    router.replace('/diagnostico/nuevo');
    return null;
  }

  const equipo = getEquipoInfo(currentSession.equipo.tipo);
  const fallas = getFallas(currentSession.equipo.tipo);

  const handleStart = () => {
    if (!selectedFalla) {
      Alert.alert('Selecciona la falla', 'Debes seleccionar el síntoma principal del equipo.');
      return;
    }
    setEquipo({
      tipo: currentSession.equipo.tipo,
      marca,
      modelo,
      serie,
      fallaId: selectedFalla.id,
      fallaLabel: selectedFalla.label,
      treeId: selectedFalla.treeId,
    });
    router.push('/diagnostico/arbol');
  };

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: c.background }}
      contentContainerStyle={{ padding: 20, paddingBottom: insets.bottom + 40 }}
    >
      <StepProgress steps={STEPS} currentIndex={1} />

      {/* Equipo info */}
      <View style={[styles.equipoBanner, { backgroundColor: equipo.color + '15', borderRadius: colors.radius }]}>
        <Feather name={equipo.icon as keyof typeof Feather.glyphMap} size={20} color={equipo.color} />
        <Text style={[styles.equipoBannerText, { color: equipo.color }]}>{equipo.label}</Text>
      </View>

      <Text style={[styles.sectionTitle, { color: c.foreground }]}>Datos del equipo</Text>
      <FormField label="Marca" value={marca} onChangeText={setMarca} placeholder="Samsung, LG, Kalley..." />
      <FormField label="Modelo" value={modelo} onChangeText={setModelo} placeholder="Modelo del equipo" />
      <FormField label="N° de serie" value={serie} onChangeText={setSerie} placeholder="Número de serie" />

      <Text style={[styles.sectionTitle, { color: c.foreground, marginTop: 8 }]}>Síntoma principal</Text>
      <Text style={[styles.hint, { color: c.mutedForeground }]}>
        Selecciona el síntoma que reporta el cliente. Esto define el árbol de diagnóstico a seguir.
      </Text>

      <View style={styles.fallaList}>
        {fallas.map((f) => {
          const sel = selectedFalla?.id === f.id;
          return (
            <TouchableOpacity
              key={f.id}
              onPress={() => setSelectedFalla(f)}
              activeOpacity={0.75}
              style={[
                styles.fallaItem,
                {
                  backgroundColor: sel ? c.primary + '12' : c.card,
                  borderColor: sel ? c.primary : c.border,
                  borderRadius: colors.radius,
                },
              ]}
            >
              <View style={[styles.fallaIcon, { backgroundColor: sel ? c.primary + '20' : c.muted, borderRadius: 10 }]}>
                <Feather name={f.icon as keyof typeof Feather.glyphMap} size={18} color={sel ? c.primary : c.mutedForeground} />
              </View>
              <Text style={[styles.fallaLabel, { color: sel ? c.primary : c.foreground }]}>{f.label}</Text>
              {sel && <Feather name="check-circle" size={18} color={c.primary} />}
            </TouchableOpacity>
          );
        })}
      </View>

      <PrimaryButton
        label="Iniciar árbol de diagnóstico"
        icon="git-branch"
        onPress={handleStart}
        disabled={!selectedFalla}
      />
      <View style={{ height: 12 }} />
      <PrimaryButton label="Volver" variant="outline" onPress={() => router.back()} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  equipoBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    padding: 12,
    marginBottom: 20,
  },
  equipoBannerText: {
    fontSize: 15,
    fontWeight: '700',
    fontFamily: Platform.select({ ios: 'System', default: 'Inter_700Bold' }),
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 12,
    fontFamily: Platform.select({ ios: 'System', default: 'Inter_700Bold' }),
  },
  hint: {
    fontSize: 13,
    lineHeight: 18,
    marginBottom: 12,
    fontFamily: Platform.select({ ios: 'System', default: 'Inter_400Regular' }),
  },
  fallaList: {
    gap: 8,
    marginBottom: 20,
  },
  fallaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 14,
    borderWidth: 1.5,
  },
  fallaIcon: {
    width: 38,
    height: 38,
    alignItems: 'center',
    justifyContent: 'center',
  },
  fallaLabel: {
    flex: 1,
    fontSize: 14,
    fontWeight: '500',
    fontFamily: Platform.select({ ios: 'System', default: 'Inter_500Medium' }),
  },
});
